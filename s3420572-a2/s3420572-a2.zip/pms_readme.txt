/**********************************************************************************
* COSC1283/1284 - Programming Techniques
* Semester 1 2013 Assignment #2 - SCSIT Program Management System
# Full Name        : Hartanto Poniman Noerdjaja
# Student Number   : 3420572
# Yallara Username : s3420572
# Course Code      : CSOC1284
# Program Code     : BP162
* Start up code provided by Paul Miller and Xiaodong Li
***********************************************************************************/

If selected, do you grant permission for your assignment
to be released as an anonymous student sample solution?
--------------------------------------------------------
YES


Known bugs:
-----------
When you add the new Program (assume New Program ID will be P0008) , next after you add , you delete the 'P0008' , then when you add new program the program ID will be P0009 not P0008

when save & exit , the program write to course.dat and when writing it not sorted based on the courseID.

Incomplete functionality:
-------------------------
All Functionality should work well.


Assumptions:
------------
when you add program and add course All input are in the correct format, for example: when you add new Program fill the data with the correct input. no validation on this for incorrect format of Input just length of character validated


Any other notes for the marker:
-------------------------------
sometimes when i run on yallara the program will error sometimes not, but when i tried on my computer works really well no error. but on the last try on yallara it works well.in case shit happens on yallara tried on another computer, thank you.
